package com.company;

public class Player {

    private String playerName;

    public Player(String playerName) {
        this.playerName = playerName;
    }
}
